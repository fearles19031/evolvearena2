# EvolveArena — tarayıcı / telefon girişi (pygbag)
import asyncio
import sys
import platform as pf
import pygame  # pygbag paketi bu satırdan tanır


def _say(t):
    try:
        pf.window.evoStatus(t)
    except Exception:
        pass


def _load_game():
    """Oyun modülünü yükler. Önce önceden derlenmiş bayt kodu (kasma_arena13.bin):
    tarayıcıda 3 MB'lık kaynağı derlemek açılışı saniyelerce uzatıyordu.
    Python sürümü tutmazsa normal kaynak dosyasına düşülür."""
    import os, sys, marshal, types, importlib.util
    here = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
    b = os.path.join(here, "kasma_arena13.bin")
    try:
        with open(b, "rb") as f:
            data = f.read()
        if data[:4] == importlib.util.MAGIC_NUMBER:
            code = marshal.loads(data[16:])
            mod = types.ModuleType("kasma_arena13")
            mod.__file__ = os.path.join(here, "kasma_arena13.py")
            sys.modules["kasma_arena13"] = mod
            try:
                exec(code, mod.__dict__)
            except BaseException:
                sys.modules.pop("kasma_arena13", None)
                raise
            return mod
    except FileNotFoundError:
        pass
    import kasma_arena13
    return kasma_arena13


async def main():
    _say("Oyun yükleniyor...")
    await asyncio.sleep(0)
    try:
        ka = _load_game()
        _say("Hazırlanıyor...")
        await asyncio.sleep(0)
        app = ka.App()
    except BaseException as ex:
        import traceback
        txt = "".join(traceback.format_exception(ex))
        print(txt)
        _say("Açılış hatası: " + txt[-300:])
        try:
            pf.window.document.title = "BOOTERR " + txt[-900:].replace(chr(10), " | ")
        except Exception:
            pass
        return
    try:
        pf.window.evoHideSplash()
        pf.window.evoFit()
    except Exception:
        pass
    await app.run_loop_async()


asyncio.run(main())
